package com.example.college;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollegeFinder extends Fragment {

    String tempacc, tempgmat, tempfees, tempsal;
    private ViewPager2 viewPager2;
    private Handler slideHandler = new Handler();
    private Button apply;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstances) {

        View v = inflater.inflate(R.layout.fragment_collegefinder, container, false);
        setHasOptionsMenu(true);

        apply = v.findViewById(R.id.button);

        viewPager2 = v.findViewById(R.id.viewPagerImageSlider);

        List<SliderItem> sliderItems = new ArrayList<>();
        sliderItems.add(new SliderItem(R.drawable.slide1));
        sliderItems.add(new SliderItem(R.drawable.slide1));
        sliderItems.add(new SliderItem(R.drawable.slide1));
        sliderItems.add(new SliderItem(R.drawable.slide1));
        sliderItems.add(new SliderItem(R.drawable.slide1));

//        adapter = new CustomSwipeAdapter(this.getActivity());
        viewPager2.setAdapter(new SliderAdapter(sliderItems, viewPager2));
        viewPager2.setClipToPadding(false);
        viewPager2.setClipChildren(false);
        viewPager2.setOffscreenPageLimit(3);
        viewPager2.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);

        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(40));


        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.85f + r * 0.15f);
            }
        });

        viewPager2.setPageTransformer(compositePageTransformer);


        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                slideHandler.removeCallbacks(sliderRunnable);
                slideHandler.postDelayed(sliderRunnable, 3000);
            }
        });



        CollegeFilter cf = new CollegeFilter();

        Spinner dropdownacc = v.findViewById(R.id.acc);
        Spinner dropdowngmat = v.findViewById(R.id.gmat);
        Spinner dropdownfees = v.findViewById(R.id.fees);
        Spinner dropdownsal = v.findViewById(R.id.sal);

        final String[] choice_acc = {""};
        final String[] choice_gmat = {""};
        final String[] choice_fees = {""};
        final String[] choice_sal = {""};

        final String[] choice_accval = {""};
        final String[] choice_gmatval = {""};
        final String[] choice_feesval = {""};
        final String[] choice_salval = {""};


        String[] college_names = {"Harvard", "Stanford", "INSEAD", "Virginia Tech", "MIT"} ;

        // Input choices
        String[] accinput = {"Any",">20%", ">30%", ">45%", ">60%", ">80%"};
        String[] accval = {"0","20", "30", "45", "60", "80" };

        String[] gmatinput = {"Any",">380", ">350", ">290", ">200", ">150", ">90"};
        String[] gmatval = {"0","380", "350", "290", "200", "150", "90"};

        String[] feesinput = {"Any","<100000", "<150000", "<200000", "<270000", "<350000"};
        String[] feesval = {"99999999","100000", "150000", "200000", "270000", "350000"};

        String[] salinput = {"Any",">100000", ">150000", ">200000", ">270000", ">350000"};
        String[] salval = {"0","100000", "150000", "200000", "270000", "350000"};

        choice_acc[0] = "Any";
        choice_gmat[0] = "Any";
        choice_fees[0] = "Any";
        choice_sal[0] = "Any";

        choice_accval[0] = "0";
        choice_gmatval[0] = "0";
        choice_feesval[0] = "99999999";
        choice_salval[0] = "0";

        ArrayAdapter<String> adapteracc = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, accinput);
        dropdownacc.setAdapter(adapteracc);

        ArrayAdapter<String> adaptergmat = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, gmatinput);
        dropdowngmat.setAdapter(adaptergmat);

        ArrayAdapter<String> adapterfees = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, feesinput);
        dropdownfees.setAdapter(adapterfees);

        ArrayAdapter<String> adaptersal = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, salinput);
        dropdownsal.setAdapter(adaptersal);

        dropdownacc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tempacc = dropdownacc.getSelectedItem().toString();
                for (int a = 0; a<accval.length; a++){
                    if (tempacc.equalsIgnoreCase(accinput[a])){
                        choice_acc[0] = tempacc;
                        choice_accval[0] = accval[a];
                        Log.d("Status:","Matched acc");
                        Log.d("Value in loop",choice_accval[0]);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        Log.d("Value in class",choice_accval[0]);

        dropdowngmat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tempgmat = dropdowngmat.getSelectedItem().toString();
                for (int a = 0; a<gmatval.length; a++){
                    if (tempgmat.equalsIgnoreCase(gmatinput[a])){
                        choice_gmat[0] = tempgmat;
                        choice_gmatval[0] = gmatval[a];
                        Log.d("Status:","Matched gmat");
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        dropdownfees.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tempfees = dropdownfees.getSelectedItem().toString();
                for (int a = 0; a<feesval.length; a++){
                    if (tempfees.equalsIgnoreCase(feesinput[a])){
                        choice_fees[0] = tempfees;
                        choice_feesval[0] = feesval[a];
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        dropdownsal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tempsal = dropdownsal.getSelectedItem().toString();
                for (int a = 0; a<salval.length; a++){
                    if (tempsal.equalsIgnoreCase(salinput[a])){
                        choice_sal[0] = tempsal;
                        choice_salval[0] = salval[a];
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });





        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double min_acc, max_acc, min_gmat, max_gmat, min_fees, max_fees, min_salary, max_salary;
                // defaults values
                min_acc = 0;
                max_acc = 100;
                min_gmat = 0;
                max_gmat = 400;
                min_fees = 0;
                max_fees = 9999999;
                min_salary = 0;
                max_salary = 9999999;
                String temp = "";
                min_acc = Integer.parseInt(choice_accval[0]);
                min_gmat = Integer.parseInt(choice_gmatval[0]);
                max_fees = Integer.parseInt(choice_feesval[0]);
                min_salary = Integer.parseInt(choice_salval[0]);

                Log.d("User Choice Acc", choice_accval[0]);
                Log.d("User Choice gmat", choice_gmatval[0]);
                Log.d("User Choice fees", choice_feesval[0]);
                Log.d("User Choice salary", choice_salval[0]);

                int len = cf.get_all_colleges().length;
                int[] filtered_college_indexes = new int[len];
                String[] filtered_college_names = new String[len];
                double[] filtered_college_acc_rates = new double[len];
                int[] filtered_college_gmat = new int[len];
                int[] filtered_college_fees = new int[len];
                int[] filtered_college_salary = new int[len];

                filtered_college_indexes = cf.filter(min_acc, max_acc, min_gmat, max_gmat, min_fees, max_fees, min_salary, max_salary);


                Log.d("CFil Checkpoint",""+cf.college_found);

                if (cf.college_found) {
                    filtered_college_acc_rates = cf.get_filtered_college_acc_rates(filtered_college_indexes, len);
                    filtered_college_names = cf.get_filtered_college_names(filtered_college_indexes, len);
                    filtered_college_gmat = cf.get_filtered_college_gmat(filtered_college_indexes, len);
                    filtered_college_fees = cf.get_filtered_college_fees(filtered_college_indexes, len);
                    filtered_college_salary = cf.get_filtered_college_salary(filtered_college_indexes, len);

                    for (int i = 0; i < filtered_college_names.length; i++) {
                        temp = temp + " " + filtered_college_names[i];
                    }
                    Log.d("college rec names", temp); // filtered college names

                    temp = "";
                    for (int i = 0; i < filtered_college_indexes.length; i++) {
                        temp = temp + " " + filtered_college_indexes[i];
                    }
                    Log.d("college rec indices", temp); // filtered college indices

                    int[] finalFiltered_college_gmat = filtered_college_gmat;
                    String[] finalFiltered_college_names = filtered_college_names;
                    double[] finalFiltered_college_acc_rates = filtered_college_acc_rates;
                    int[] finalFiltered_college_fees = filtered_college_fees;
                    int[] finalFiltered_college_salary = filtered_college_salary;

                    //removing the null values
                    String[] new_finalFiltered_college_names = finalFiltered_college_names;
                    List<String> list = new ArrayList<String>();

                    for (String s : finalFiltered_college_names) {
                        if (s != null && s.length() > 0) {
                            list.add(s);
                        }
                    }

                    //new array with no null values
                    new_finalFiltered_college_names = list.toArray(new String[list.size()]);

                    // display the new arrayZ
                    temp = "";
                    for (int i = 0; i < new_finalFiltered_college_names.length; i++) {
                        temp = temp + " " + new_finalFiltered_college_names[i];
                    }
                    Log.d("Filtered names", temp);


                    //populate the list view
                    ArrayAdapter<String> ls = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, new_finalFiltered_college_names);
                    ListView lv = v.findViewById(R.id.list);
                    lv.setAdapter(ls);
                    String[] final_names = new_finalFiltered_college_names;
                    double[] final_acc = finalFiltered_college_acc_rates;
                    int[] final_gmat = finalFiltered_college_gmat;
                    int[] final_fees = finalFiltered_college_fees;
                    int[] final_salary = finalFiltered_college_salary;

                    lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                            Message
//                            "Acceptance Rate: "+final_acc[i]+"\nGmat Cutoff: "+final_gmat[i]+"\nTotal Fees: "+final_fees[i]+"\nMid Career Salary: "+final_salary[i]
                        }
                    });

                } else {
                    String[] message = {"No College Found!! Change the filter"};
                    ArrayAdapter<String> ls = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, message);
                    ListView lv = v.findViewById(R.id.list);
                    lv.setAdapter(ls);
                }
            }
        });

        return v;
    }



    private Runnable sliderRunnable = new Runnable() {
        @Override
        public void run() {
            viewPager2.setCurrentItem(viewPager2.getCurrentItem() + 1);
        }
    };


    @Override
    public void onPause() {
        super.onPause();
        slideHandler.removeCallbacks(sliderRunnable);
    }

    @Override
    public void onResume() {
        super.onResume();
        slideHandler.postDelayed(sliderRunnable, 1000);
    }
}