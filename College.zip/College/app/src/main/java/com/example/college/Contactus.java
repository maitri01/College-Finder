package com.example.college;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class Contactus extends Fragment {

    EditText myEditTextSubject;
    EditText myEditTextMessage;
    Button buttonSend;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstances) {
        View v = inflater.inflate(R.layout.fragment_contactus, container, false);
        setHasOptionsMenu(true);
        myEditTextSubject = (EditText) v.findViewById(R.id.subject);
        myEditTextMessage = (EditText) v.findViewById(R.id.message);
        buttonSend = (Button) v.findViewById(R.id.send);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMail(buttonSend);
            }
        });
        return v;
    }

    public void sendMail(View buttonSend) {
//        String recipientList = mEditTextTo.getText().toString();
        String[] recipients = {"sahilpatki1234@gmail.com", "maitriv2001@gmail.com"};
        String subject = myEditTextSubject.getText().toString();
        String message = myEditTextMessage.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, recipients);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, message);
        intent.setType("message/rfc822");
        try {
            startActivity(Intent.createChooser(intent, "Send email with...?"));
        } catch (android.content.ActivityNotFoundException exception) {
            Toast.makeText(Contactus.this.getActivity(), "No email clients installed on device!", Toast.LENGTH_LONG).show();
        }

    }

}

