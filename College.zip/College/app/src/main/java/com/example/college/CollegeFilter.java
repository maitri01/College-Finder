package com.example.college;

import android.util.Log;

public class CollegeFilter {

    String[] college_names = {"Harvard", "Stanford", "INSEAD", "Virginia Tech", "MIT"} ;
    int[] enroll = {20000, 30000, 5000, 6000, 30000};
    int[] accept = {900, 2200, 200, 4500, 1200};
    int[] gmat = {370, 300, 120, 210, 380};
    int[] fees = {300000, 250000, 220000, 150000, 50000};
    int[] salary = {400000, 300000, 150000, 150000, 400000};
    boolean college_found = false;

    double[] acc_rate = new double[5];

    public int[] filter(double min_acc, double max_acc, double min_gmat, double max_gmat, double min_fees, double max_fees, double min_salary, double max_salary){
//        String[] filtered_college_names = new String[college_names.length];
        college_found = false;
        int[] filtered_college_indexes = new int[college_names.length];
        int k = 0;
        for (int i = 0; i<college_names.length; i++){
            acc_rate[i] = ((double) accept[i])/ ((double) enroll[i]) * 100;
        }

        for (int i = 0; i<college_names.length; i++){
            if (acc_rate[i]>min_acc && acc_rate[i]<max_acc && gmat[i]>min_gmat && gmat[i]<max_gmat &&fees[i]>min_fees && fees[i]<max_fees &&salary[i]>min_salary && salary[i]<max_salary){
//                filtered_college_names[k++] = college_names[i];
                filtered_college_indexes[k++] = i;
                college_found = true;
                Log.d("CFil Checkpoint","Reached");
            }
        }
        return filtered_college_indexes;
    }

    public String[] get_all_colleges(){
        return college_names;
    }
    public double[] get_all_acc_rates(){
        for (int i = 0; i<college_names.length; i++){
            acc_rate[i] = ((double) accept[i])/ ((double) enroll[i]) * 100;
        }
        return acc_rate;
    }
    public int[] get_all_gmat(){
        return gmat;
    }
    public int[] get_all_fees(){
        return fees;
    }
    public int[] get_all_salary(){
        return salary;
    }



    public String[] get_filtered_college_names(int[] filtered_college_indexes, int len){
        String[] filtered_college_names = new String[len];
        int k = 0;
        for (int i = 0; i < len; i++){
            if (filtered_college_indexes[k] == i){
                filtered_college_names[k] = college_names[i];
                k+=1;
            }
        }
        return filtered_college_names;
    }
    public double[] get_filtered_college_acc_rates(int[] filtered_college_indexes, int len){
        double[] filtered_college_acc_rates = new double[len];
        for (int i = 0; i<college_names.length; i++){
            acc_rate[i] = ((double) accept[i])/ ((double) enroll[i]) * 100;
        }
        int k = 0;
        for (int i = 0; i < len; i++){
            if (filtered_college_indexes[k] == i){
                filtered_college_acc_rates[k] = acc_rate[i];
                k+=1;
            }
        }
        return filtered_college_acc_rates;
    }
    public int[] get_filtered_college_gmat(int[] filtered_college_indexes, int len){
        int[] filtered_college_gmat = new int[len];
        int k = 0;
        for (int i = 0; i < len; i++){
            if (filtered_college_indexes[k] == i){
                filtered_college_gmat[k] = gmat[i];
                k+=1;
            }
        }
        return filtered_college_gmat;
    }
    public int[] get_filtered_college_fees(int[] filtered_college_indexes, int len){
        int[] filtered_college_fees = new int[len];
        int k = 0;
        for (int i = 0; i < len; i++){
            if (filtered_college_indexes[k] == i){
                filtered_college_fees[k] = fees[i];
                k+=1;
            }
        }
        return filtered_college_fees;
    }
    public int[] get_filtered_college_salary(int[] filtered_college_indexes, int len){
        int[] filtered_college_salary = new int[len];
        int k = 0;
        for (int i = 0; i < len; i++){
            if (filtered_college_indexes[k] == i){
                filtered_college_salary[k] = salary[i];
                k+=1;
            }
        }
        return filtered_college_salary;
    }

}