package com.example.college;

public class SliderItem {
    private int image;

    SliderItem(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

}
