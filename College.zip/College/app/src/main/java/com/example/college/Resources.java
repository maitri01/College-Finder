package com.example.college;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

public class Resources extends Fragment {

    String i1;
    WebView wb;
    private ViewPager2 viewPager2;
    private Handler slideHandler = new Handler();


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstances) {
        View v = inflater.inflate(R.layout.fragment_resource, container, false);

        viewPager2 = v.findViewById(R.id.viewPagerImageSlider2);

        List<SliderItem2> sliderItems = new ArrayList<>();
        sliderItems.add(new SliderItem2("https://youtu.be/8CcPh5krvOg"));
        sliderItems.add(new SliderItem2("https://youtu.be/4Us_nFgGEw0"));
        sliderItems.add(new SliderItem2("https://youtu.be/bQSuunMhT1Q"));
        sliderItems.add(new SliderItem2("https://youtu.be/ODcHjbeiftA"));
        sliderItems.add(new SliderItem2("https://youtu.be/2SctYMqdwkM"));

//        adapter = new CustomSwipeAdapter(this.getActivity());

        viewPager2.setAdapter(new SliderAdapter2(sliderItems, viewPager2));
        viewPager2.setClipToPadding(false);
        viewPager2.setClipChildren(false);
        viewPager2.setOffscreenPageLimit(3);
        viewPager2.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);

        CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
        compositePageTransformer.addTransformer(new MarginPageTransformer(40));
        compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
            @Override
            public void transformPage(@NonNull View page, float position) {
                float r = 1 - Math.abs(position);
                page.setScaleY(0.85f + r * 0.15f);
            }
        });

        viewPager2.setPageTransformer(compositePageTransformer);
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                slideHandler.removeCallbacks(sliderRunnable);
                slideHandler.postDelayed(sliderRunnable, 7000);
            }
        });


        Spinner dropdown1 = v.findViewById(R.id.spinner1);
        wb = v.findViewById(R.id.webView);

        final String[] choice_name = {""};
        final String[] choice_link = {""};

        choice_name[0] = "GRE";
        choice_link[0] = "https://youtu.be/8CcPh5krvOg";
        String[] names = {"GRE", "GMAT", "Advanced GRE Prep", "GRE Verbal Prep", "GRE Math Prep"};
        String[] links = {"https://youtu.be/8CcPh5krvOg", "https://youtu.be/4Us_nFgGEw0", "https://youtu.be/bQSuunMhT1Q", "https://youtu.be/ODcHjbeiftA", "https://youtu.be/2SctYMqdwkM"};
        wb.setWebViewClient(new MyBrowser());

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, names);
        dropdown1.setAdapter(adapter1);

        wb.getSettings().setLoadsImagesAutomatically(true);
        wb.getSettings().setJavaScriptEnabled(true);
        wb.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        dropdown1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                i1 = dropdown1.getSelectedItem().toString();
                for (int a = 0; a<links.length; a++){
                    if (i1.equalsIgnoreCase(names[a])){
                        choice_name[0] = i1;
                        choice_link[0] = links[i];
                        wb.loadUrl(choice_link[0]);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        return v;
    }

    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }
    private Runnable sliderRunnable = new Runnable() {
        @Override
        public void run() {
            viewPager2.setCurrentItem(viewPager2.getCurrentItem() + 1);
        }
    };


    @Override
    public void onPause() {
        super.onPause();
        slideHandler.removeCallbacks(sliderRunnable);
    }

    @Override
    public void onResume() {
        super.onResume();
        slideHandler.postDelayed(sliderRunnable, 1000);
    }
}
