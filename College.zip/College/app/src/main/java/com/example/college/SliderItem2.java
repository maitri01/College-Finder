package com.example.college;

public class SliderItem2 {
    private String url;

    SliderItem2(String url) {
        this.url = url;
    }

    public String getImage() {
        return url;
    }

}
